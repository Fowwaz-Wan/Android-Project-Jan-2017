package com.example.wan.danoteapp;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Wan on 06-Mar-17.
 */

public class DBNote extends SQLiteOpenHelper
{
    public DBNote(Context context)
    {
        super(context, DBExtract.DB_NAME, null, DBExtract.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + DBExtract.DBData.TABLE + " ( " +
                DBExtract.DBData._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                DBExtract.DBData.COL_TASK_TITLE + " TEXT NOT NULL)" ;

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DBExtract.DBData.TABLE);
        onCreate(db);
    }
}
