package com.example.wan.danoteapp;

/**
 * Created by Wan on 06-Mar-17.
 */
import android.provider.BaseColumns;

public class DBExtract {
    public static final String DB_NAME = "com.wan.db";
    public static final int DB_VERSION = 1;

    public class DBData implements BaseColumns {
        public static final String TABLE = "notes";

        public static final String COL_TASK_TITLE = "title";


    }

}
